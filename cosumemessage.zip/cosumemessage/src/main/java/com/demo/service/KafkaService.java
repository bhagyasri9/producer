package com.demo.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.demo.model.Employee;

@Service
public class KafkaService {
	@KafkaListener(topics = "Topic_Consumer", groupId = "gropu_Json_id", containerFactory = "EmployeeListner") 
public void publish(Employee emp) 
{ 
 System.out.println("New Entry: " + emp); 
} 
}
